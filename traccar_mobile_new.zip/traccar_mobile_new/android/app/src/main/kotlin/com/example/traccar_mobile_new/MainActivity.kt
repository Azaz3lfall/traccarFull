package com.example.traccar_mobile_new

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
