import 'package:shared_preferences/shared_preferences.dart';

class AppConfig {
  static const String _serverUrlKey = 'server_url';
  static const String _userEmailKey = 'user_email';
  static const String _userPasswordKey = 'user_password';
  static const String _isLoggedInKey = 'is_logged_in';
  static const String _fcmTokenKey = 'fcm_token';
  
  static SharedPreferences? _prefs;
  
  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }
  
  // Server URL
  static String get serverUrl => _prefs?.getString(_serverUrlKey) ?? 'https://demo.traccar.org';
  static Future<void> setServerUrl(String url) async {
    await _prefs?.setString(_serverUrlKey, url);
  }
  
  // User credentials
  static String? get userEmail => _prefs?.getString(_userEmailKey);
  static Future<void> setUserEmail(String email) async {
    await _prefs?.setString(_userEmailKey, email);
  }
  
  static String? get userPassword => _prefs?.getString(_userPasswordKey);
  static Future<void> setUserPassword(String password) async {
    await _prefs?.setString(_userPasswordKey, password);
  }
  
  // Login state
  static bool get isLoggedIn => _prefs?.getBool(_isLoggedInKey) ?? false;
  static Future<void> setLoggedIn(bool value) async {
    await _prefs?.setBool(_isLoggedInKey, value);
  }
  
  // FCM Token
  static String? get fcmToken => _prefs?.getString(_fcmTokenKey);
  static Future<void> setFcmToken(String token) async {
    await _prefs?.setString(_fcmTokenKey, token);
  }
  
  // Clear all data
  static Future<void> clearAll() async {
    await _prefs?.clear();
  }
  
  // Logout
  static Future<void> logout() async {
    await _prefs?.remove(_userEmailKey);
    await _prefs?.remove(_userPasswordKey);
    await _prefs?.setBool(_isLoggedInKey, false);
  }
}
