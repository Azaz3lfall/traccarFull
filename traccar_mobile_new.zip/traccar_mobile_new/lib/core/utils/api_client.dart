import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../constants/api_constants.dart';
import '../../domain/models/device.dart';
import '../../domain/models/position.dart';
import '../../domain/models/event.dart';
import '../../domain/models/geofence.dart';
import '../../domain/models/user.dart';

class ApiClient {
  static final ApiClient _instance = ApiClient._internal();
  factory ApiClient() => _instance;
  ApiClient._internal();

  late Dio _dio;
  String _baseUrl = ApiConstants.baseUrl;
  String? _sessionCookie;

  Future<void> initialize(String baseUrl) async {
    _baseUrl = baseUrl;
    _dio = Dio(BaseOptions(
      baseUrl: _baseUrl,
      connectTimeout: Duration(milliseconds: ApiConstants.connectTimeout),
      receiveTimeout: Duration(milliseconds: ApiConstants.receiveTimeout),
      sendTimeout: Duration(milliseconds: ApiConstants.sendTimeout),
      headers: {
        ApiConstants.contentTypeHeader: ApiConstants.applicationJson,
      },
    ));

    // Add interceptors
    _dio.interceptors.add(LogInterceptor(
      requestBody: true,
      responseBody: true,
      logPrint: (obj) => print('API: $obj'),
    ));

    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) async {
        // Add session cookie if available
        if (_sessionCookie != null) {
          options.headers['Cookie'] = _sessionCookie;
        }
        handler.next(options);
      },
      onResponse: (response, handler) {
        // Extract session cookie from response
        final setCookie = response.headers['set-cookie'];
        if (setCookie != null && setCookie.isNotEmpty) {
          _sessionCookie = setCookie.first.split(';').first;
        }
        handler.next(response);
      },
      onError: (error, handler) async {
        if (error.response?.statusCode == 401) {
          // Handle unauthorized - clear session
          await _clearSession();
        }
        handler.next(error);
      },
    ));

    // Load saved session
    await _loadSession();
  }

  Future<void> _loadSession() async {
    final prefs = await SharedPreferences.getInstance();
    _sessionCookie = prefs.getString('session_cookie');
  }

  Future<void> _saveSession() async {
    if (_sessionCookie != null) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('session_cookie', _sessionCookie!);
    }
  }

  Future<void> _clearSession() async {
    _sessionCookie = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('session_cookie');
  }

  // Authentication
  Future<User> login(String email, String password) async {
    try {
      final formData = {
        'email': email,
        'password': password,
      };

      final response = await _dio.post(
        ApiConstants.loginEndpoint,
        data: formData,
        options: Options(
          headers: {
            ApiConstants.contentTypeHeader: ApiConstants.formUrlEncoded,
          },
        ),
      );

      if (response.statusCode == 200) {
        await _saveSession();
        return User.fromJson(response.data);
      } else {
        throw DioException(
          requestOptions: response.requestOptions,
          response: response,
          message: 'Login failed',
        );
      }
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<void> logout() async {
    try {
      await _dio.delete(ApiConstants.loginEndpoint);
    } catch (e) {
      // Ignore logout errors
    } finally {
      await _clearSession();
    }
  }

  // Devices
  Future<List<Device>> getDevices() async {
    try {
      final response = await _dio.get(ApiConstants.devicesEndpoint);
      return (response.data as List)
          .map((json) => Device.fromJson(json))
          .toList();
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<Device> getDevice(int id) async {
    try {
      final response = await _dio.get('${ApiConstants.devicesEndpoint}/$id');
      return Device.fromJson(response.data);
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<Device> createDevice(Device device) async {
    try {
      final response = await _dio.post(
        ApiConstants.devicesEndpoint,
        data: device.toJson(),
      );
      return Device.fromJson(response.data);
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<Device> updateDevice(int id, Device device) async {
    try {
      final response = await _dio.put(
        '${ApiConstants.devicesEndpoint}/$id',
        data: device.toJson(),
      );
      return Device.fromJson(response.data);
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<void> deleteDevice(int id) async {
    try {
      await _dio.delete('${ApiConstants.devicesEndpoint}/$id');
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  // Positions
  Future<List<Position>> getPositions({int? deviceId}) async {
    try {
      final queryParams = deviceId != null ? {'deviceId': deviceId} : null;
      final response = await _dio.get(
        ApiConstants.positionsEndpoint,
        queryParameters: queryParams,
      );
      return (response.data as List)
          .map((json) => Position.fromJson(json))
          .toList();
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<Position> getPosition(int id) async {
    try {
      final response = await _dio.get('${ApiConstants.positionsEndpoint}/$id');
      return Position.fromJson(response.data);
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  // Events
  Future<List<Event>> getEvents({
    int? deviceId,
    String? from,
    String? to,
    String? type,
  }) async {
    try {
      final queryParams = <String, dynamic>{};
      if (deviceId != null) queryParams['deviceId'] = deviceId;
      if (from != null) queryParams['from'] = from;
      if (to != null) queryParams['to'] = to;
      if (type != null) queryParams['type'] = type;

      final response = await _dio.get(
        ApiConstants.eventsEndpoint,
        queryParameters: queryParams,
      );
      return (response.data as List)
          .map((json) => Event.fromJson(json))
          .toList();
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<Event> getEvent(int id) async {
    try {
      final response = await _dio.get('${ApiConstants.eventsEndpoint}/$id');
      return Event.fromJson(response.data);
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  // Geofences
  Future<List<Geofence>> getGeofences() async {
    try {
      final response = await _dio.get(ApiConstants.geofencesEndpoint);
      return (response.data as List)
          .map((json) => Geofence.fromJson(json))
          .toList();
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<Geofence> getGeofence(int id) async {
    try {
      final response = await _dio.get('${ApiConstants.geofencesEndpoint}/$id');
      return Geofence.fromJson(response.data);
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<Geofence> createGeofence(Geofence geofence) async {
    try {
      final response = await _dio.post(
        ApiConstants.geofencesEndpoint,
        data: geofence.toJson(),
      );
      return Geofence.fromJson(response.data);
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<Geofence> updateGeofence(int id, Geofence geofence) async {
    try {
      final response = await _dio.put(
        '${ApiConstants.geofencesEndpoint}/$id',
        data: geofence.toJson(),
      );
      return Geofence.fromJson(response.data);
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<void> deleteGeofence(int id) async {
    try {
      await _dio.delete('${ApiConstants.geofencesEndpoint}/$id');
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  // Users
  Future<List<User>> getUsers() async {
    try {
      final response = await _dio.get(ApiConstants.usersEndpoint);
      return (response.data as List)
          .map((json) => User.fromJson(json))
          .toList();
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<User> getCurrentUser() async {
    try {
      final response = await _dio.get('${ApiConstants.usersEndpoint}/me');
      return User.fromJson(response.data);
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  // Server info
  Future<Map<String, dynamic>> getServerInfo() async {
    try {
      final response = await _dio.get(ApiConstants.serverEndpoint);
      return response.data;
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  // Error handling
  Exception _handleError(DioException error) {
    String message = 'An error occurred';
    
    if (error.response != null) {
      switch (error.response!.statusCode) {
        case 400:
          message = 'Bad request';
          break;
        case 401:
          message = 'Unauthorized - please login again';
          break;
        case 403:
          message = 'Forbidden - insufficient permissions';
          break;
        case 404:
          message = 'Resource not found';
          break;
        case 500:
          message = 'Server error';
          break;
        default:
          message = 'HTTP ${error.response!.statusCode} error';
      }
    } else if (error.type == DioExceptionType.connectionTimeout) {
      message = 'Connection timeout';
    } else if (error.type == DioExceptionType.receiveTimeout) {
      message = 'Receive timeout';
    } else if (error.type == DioExceptionType.connectionError) {
      message = 'Connection error - check your internet connection';
    }

    return Exception(message);
  }
}
