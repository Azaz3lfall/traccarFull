import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class DeviceIcons {
  // Mapeamento de categorias para arquivos de imagem PNG
  static const Map<String, String> _categoryImagePaths = {
    'animal': 'assets/icons/animal.png',
    'bicycle': 'assets/icons/bicycle.png',
    'boat': 'assets/icons/boat.png',
    'bus': 'assets/icons/bus.png',
    'car': 'assets/icons/car.png',
    'camper': 'assets/icons/camper.png',
    'crane': 'assets/icons/crane.png',
    'default': 'assets/icons/default.png',
    'helicopter': 'assets/icons/helicopter.png',
    'motorcycle': 'assets/icons/motorcycle.png',
    'offroad': 'assets/icons/offroad.png',
    'person': 'assets/icons/person.png',
    'pickup': 'assets/icons/pickup.png',
    'plane': 'assets/icons/plane.png',
    'scooter': 'assets/icons/scooter.png',
    'ship': 'assets/icons/ship.png',
    'tractor': 'assets/icons/tractor.png',
    'trailer': 'assets/icons/trailer.png',
    'train': 'assets/icons/train.png',
    'tram': 'assets/icons/tram.png',
    'trolleybus': 'assets/icons/trolleybus.png',
    'truck': 'assets/icons/truck.png',
    'van': 'assets/icons/van.png',
  };

  // Ícones originais do Traccar para start e finish
  static const Map<String, IconData> _traccarIcons = {
    'start': CupertinoIcons.play_circle,
    'finish': CupertinoIcons.stop_circle,
  };

  static String getImagePathForCategory(String? category) {
    if (category == null || category.isEmpty) {
      return _categoryImagePaths['default']!;
    }
    return _categoryImagePaths[category.toLowerCase()] ?? _categoryImagePaths['default']!;
  }

  static IconData? getTraccarIconForCategory(String? category) {
    if (category == null || category.isEmpty) {
      return null;
    }
    return _traccarIcons[category.toLowerCase()];
  }

  static bool isTraccarIcon(String? category) {
    if (category == null || category.isEmpty) {
      return false;
    }
    return _traccarIcons.containsKey(category.toLowerCase());
  }

  static Widget getIconWidget(String? category, {double size = 24, Color? color}) {
    if (isTraccarIcon(category)) {
      return Icon(
        getTraccarIconForCategory(category),
        size: size,
        color: color,
      );
    } else {
      return Image.asset(
        getImagePathForCategory(category),
        width: size,
        height: size,
        fit: BoxFit.contain,
        errorBuilder: (context, error, stackTrace) {
          return Icon(
            CupertinoIcons.location,
            size: size,
            color: color,
          );
        },
      );
    }
  }

  static List<String> getAvailableCategories() {
    return [..._categoryImagePaths.keys, ..._traccarIcons.keys];
  }
}
