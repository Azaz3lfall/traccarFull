class ApiConstants {
  // Base URLs
  static const String baseUrl = 'https://gps.codeartisan.cloud';
  static const String wsUrl = 'wss://gps.codeartisan.cloud';
  
  // API Endpoints
  static const String loginEndpoint = '/api/session';
  static const String devicesEndpoint = '/api/devices';
  static const String positionsEndpoint = '/api/positions';
  static const String eventsEndpoint = '/api/events';
  static const String geofencesEndpoint = '/api/geofences';
  static const String groupsEndpoint = '/api/groups';
  static const String driversEndpoint = '/api/drivers';
  static const String maintenanceEndpoint = '/api/maintenance';
  static const String calendarsEndpoint = '/api/calendars';
  static const String commandsEndpoint = '/api/commands';
  static const String notificationsEndpoint = '/api/notifications';
  static const String reportsEndpoint = '/api/reports';
  static const String socketEndpoint = '/api/socket';
  static const String serverEndpoint = '/api/server';
  static const String usersEndpoint = '/api/users';
  
  // WebSocket
  static const String wsPath = '/api/socket';
  
  // Headers
  static const String contentTypeHeader = 'Content-Type';
  static const String applicationJson = 'application/json';
  static const String formUrlEncoded = 'application/x-www-form-urlencoded';
  
  // Timeouts
  static const int connectTimeout = 30000; // 30 seconds
  static const int receiveTimeout = 30000; // 30 seconds
  static const int sendTimeout = 30000; // 30 seconds
  
  // Retry
  static const int maxRetries = 3;
  static const int retryDelay = 1000; // 1 second
}
