// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

User _$UserFromJson(Map<String, dynamic> json) => User(
  id: (json['id'] as num).toInt(),
  name: json['name'] as String,
  email: json['email'] as String,
  readonly: json['readonly'] as bool,
  administrator: json['administrator'] as bool,
  phone: json['phone'] as String?,
  expirationTime: json['expirationTime'] as String?,
  attributes: json['attributes'] as Map<String, dynamic>?,
);

Map<String, dynamic> _$UserToJson(User instance) => <String, dynamic>{
  'id': instance.id,
  'name': instance.name,
  'email': instance.email,
  'readonly': instance.readonly,
  'administrator': instance.administrator,
  'phone': instance.phone,
  'expirationTime': instance.expirationTime,
  'attributes': instance.attributes,
};
