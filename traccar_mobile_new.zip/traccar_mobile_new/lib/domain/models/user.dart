import 'package:json_annotation/json_annotation.dart';

part 'user.g.dart';

@JsonSerializable()
class User {
  final int id;
  final String name;
  final String email;
  final bool readonly;
  final bool administrator;
  final String? phone;
  final String? expirationTime;
  final Map<String, dynamic>? attributes;

  const User({
    required this.id,
    required this.name,
    required this.email,
    required this.readonly,
    required this.administrator,
    this.phone,
    this.expirationTime,
    this.attributes,
  });

  factory User.fromJson(Map<String, dynamic> json) => _$UserFromJson(json);
  Map<String, dynamic> toJson() => _$UserToJson(this);

  User copyWith({
    int? id,
    String? name,
    String? email,
    bool? readonly,
    bool? administrator,
    String? phone,
    String? expirationTime,
    Map<String, dynamic>? attributes,
  }) {
    return User(
      id: id ?? this.id,
      name: name ?? this.name,
      email: email ?? this.email,
      readonly: readonly ?? this.readonly,
      administrator: administrator ?? this.administrator,
      phone: phone ?? this.phone,
      expirationTime: expirationTime ?? this.expirationTime,
      attributes: attributes ?? this.attributes,
    );
  }

  @override
  String toString() {
    return 'User(id: $id, name: $name, email: $email, administrator: $administrator)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is User && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;
}
