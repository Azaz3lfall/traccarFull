// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'event.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Event _$EventFromJson(Map<String, dynamic> json) => Event(
  id: (json['id'] as num).toInt(),
  type: json['type'] as String,
  deviceId: (json['deviceId'] as num).toInt(),
  positionId: (json['positionId'] as num?)?.toInt(),
  eventTime: json['eventTime'] as String,
  geofenceId: (json['geofenceId'] as num?)?.toInt(),
  maintenanceId: (json['maintenanceId'] as num?)?.toInt(),
  attributes: json['attributes'] as Map<String, dynamic>?,
);

Map<String, dynamic> _$EventToJson(Event instance) => <String, dynamic>{
  'id': instance.id,
  'type': instance.type,
  'deviceId': instance.deviceId,
  'positionId': instance.positionId,
  'eventTime': instance.eventTime,
  'geofenceId': instance.geofenceId,
  'maintenanceId': instance.maintenanceId,
  'attributes': instance.attributes,
};
