import 'package:json_annotation/json_annotation.dart';

part 'device.g.dart';

@JsonSerializable()
class Device {
  final int id;
  final String name;
  final String uniqueId;
  final String? phone;
  final String? model;
  final String? contact;
  final String? category;
  final int? groupId;
  final int? calendarId;
  final String? expirationTime;
  final Map<String, dynamic>? attributes;
  final String? status;
  final String? lastUpdate;
  final int? positionId;

  const Device({
    required this.id,
    required this.name,
    required this.uniqueId,
    this.phone,
    this.model,
    this.contact,
    this.category,
    this.groupId,
    this.calendarId,
    this.expirationTime,
    this.attributes,
    this.status,
    this.lastUpdate,
    this.positionId,
  });

  factory Device.fromJson(Map<String, dynamic> json) => _$DeviceFromJson(json);
  Map<String, dynamic> toJson() => _$DeviceToJson(this);

  Device copyWith({
    int? id,
    String? name,
    String? uniqueId,
    String? phone,
    String? model,
    String? contact,
    String? category,
    int? groupId,
    int? calendarId,
    String? expirationTime,
    Map<String, dynamic>? attributes,
    String? status,
    String? lastUpdate,
    int? positionId,
  }) {
    return Device(
      id: id ?? this.id,
      name: name ?? this.name,
      uniqueId: uniqueId ?? this.uniqueId,
      phone: phone ?? this.phone,
      model: model ?? this.model,
      contact: contact ?? this.contact,
      category: category ?? this.category,
      groupId: groupId ?? this.groupId,
      calendarId: calendarId ?? this.calendarId,
      expirationTime: expirationTime ?? this.expirationTime,
      attributes: attributes ?? this.attributes,
      status: status ?? this.status,
      lastUpdate: lastUpdate ?? this.lastUpdate,
      positionId: positionId ?? this.positionId,
    );
  }

  @override
  String toString() {
    return 'Device(id: $id, name: $name, uniqueId: $uniqueId, status: $status)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is Device && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;
}
