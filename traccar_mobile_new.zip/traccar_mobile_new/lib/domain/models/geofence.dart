import 'package:json_annotation/json_annotation.dart';

part 'geofence.g.dart';

@JsonSerializable()
class Geofence {
  final int id;
  final String name;
  final String? description;
  final String? area;
  final String? calendarId;
  final Map<String, dynamic>? attributes;

  const Geofence({
    required this.id,
    required this.name,
    this.description,
    this.area,
    this.calendarId,
    this.attributes,
  });

  factory Geofence.fromJson(Map<String, dynamic> json) => _$GeofenceFromJson(json);
  Map<String, dynamic> toJson() => _$GeofenceToJson(this);

  Geofence copyWith({
    int? id,
    String? name,
    String? description,
    String? area,
    String? calendarId,
    Map<String, dynamic>? attributes,
  }) {
    return Geofence(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      area: area ?? this.area,
      calendarId: calendarId ?? this.calendarId,
      attributes: attributes ?? this.attributes,
    );
  }

  @override
  String toString() {
    return 'Geofence(id: $id, name: $name)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is Geofence && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;
}
