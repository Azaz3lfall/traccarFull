import 'package:json_annotation/json_annotation.dart';

part 'position.g.dart';

@JsonSerializable()
class Position {
  final int id;
  final int deviceId;
  final double latitude;
  final double longitude;
  final double? speed;
  final double? course;
  final double? altitude;
  final double? accuracy;
  final bool? valid;
  final String? protocol;
  final String? address;
  final String? deviceTime;
  final String? fixTime;
  final String? serverTime;
  final List<int>? geofenceIds;
  final String? raw;
  final int? index;
  final double? hdop;
  final double? vdop;
  final double? pdop;
  final int? sat;
  final int? satVisible;
  final double? rssi;
  final double? coolantTemp;
  final double? engineTemp;
  final Map<String, dynamic>? attributes;

  const Position({
    required this.id,
    required this.deviceId,
    required this.latitude,
    required this.longitude,
    this.speed,
    this.course,
    this.altitude,
    this.accuracy,
    this.valid,
    this.protocol,
    this.address,
    this.deviceTime,
    this.fixTime,
    this.serverTime,
    this.geofenceIds,
    this.raw,
    this.index,
    this.hdop,
    this.vdop,
    this.pdop,
    this.sat,
    this.satVisible,
    this.rssi,
    this.coolantTemp,
    this.engineTemp,
    this.attributes,
  });

  factory Position.fromJson(Map<String, dynamic> json) => _$PositionFromJson(json);
  Map<String, dynamic> toJson() => _$PositionToJson(this);

  Position copyWith({
    int? id,
    int? deviceId,
    double? latitude,
    double? longitude,
    double? speed,
    double? course,
    double? altitude,
    double? accuracy,
    bool? valid,
    String? protocol,
    String? address,
    String? deviceTime,
    String? fixTime,
    String? serverTime,
    List<int>? geofenceIds,
    String? raw,
    int? index,
    double? hdop,
    double? vdop,
    double? pdop,
    int? sat,
    int? satVisible,
    double? rssi,
    double? coolantTemp,
    double? engineTemp,
    Map<String, dynamic>? attributes,
  }) {
    return Position(
      id: id ?? this.id,
      deviceId: deviceId ?? this.deviceId,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
      speed: speed ?? this.speed,
      course: course ?? this.course,
      altitude: altitude ?? this.altitude,
      accuracy: accuracy ?? this.accuracy,
      valid: valid ?? this.valid,
      protocol: protocol ?? this.protocol,
      address: address ?? this.address,
      deviceTime: deviceTime ?? this.deviceTime,
      fixTime: fixTime ?? this.fixTime,
      serverTime: serverTime ?? this.serverTime,
      geofenceIds: geofenceIds ?? this.geofenceIds,
      raw: raw ?? this.raw,
      index: index ?? this.index,
      hdop: hdop ?? this.hdop,
      vdop: vdop ?? this.vdop,
      pdop: pdop ?? this.pdop,
      sat: sat ?? this.sat,
      satVisible: satVisible ?? this.satVisible,
      rssi: rssi ?? this.rssi,
      coolantTemp: coolantTemp ?? this.coolantTemp,
      engineTemp: engineTemp ?? this.engineTemp,
      attributes: attributes ?? this.attributes,
    );
  }

  @override
  String toString() {
    return 'Position(id: $id, deviceId: $deviceId, lat: $latitude, lng: $longitude, speed: $speed)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is Position && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;
}
