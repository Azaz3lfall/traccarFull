// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'position.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Position _$PositionFromJson(Map<String, dynamic> json) => Position(
  id: (json['id'] as num).toInt(),
  deviceId: (json['deviceId'] as num).toInt(),
  latitude: (json['latitude'] as num).toDouble(),
  longitude: (json['longitude'] as num).toDouble(),
  speed: (json['speed'] as num?)?.toDouble(),
  course: (json['course'] as num?)?.toDouble(),
  altitude: (json['altitude'] as num?)?.toDouble(),
  accuracy: (json['accuracy'] as num?)?.toDouble(),
  valid: json['valid'] as bool?,
  protocol: json['protocol'] as String?,
  address: json['address'] as String?,
  deviceTime: json['deviceTime'] as String?,
  fixTime: json['fixTime'] as String?,
  serverTime: json['serverTime'] as String?,
  geofenceIds: (json['geofenceIds'] as List<dynamic>?)
      ?.map((e) => (e as num).toInt())
      .toList(),
  raw: json['raw'] as String?,
  index: (json['index'] as num?)?.toInt(),
  hdop: (json['hdop'] as num?)?.toDouble(),
  vdop: (json['vdop'] as num?)?.toDouble(),
  pdop: (json['pdop'] as num?)?.toDouble(),
  sat: (json['sat'] as num?)?.toInt(),
  satVisible: (json['satVisible'] as num?)?.toInt(),
  rssi: (json['rssi'] as num?)?.toDouble(),
  coolantTemp: (json['coolantTemp'] as num?)?.toDouble(),
  engineTemp: (json['engineTemp'] as num?)?.toDouble(),
  attributes: json['attributes'] as Map<String, dynamic>?,
);

Map<String, dynamic> _$PositionToJson(Position instance) => <String, dynamic>{
  'id': instance.id,
  'deviceId': instance.deviceId,
  'latitude': instance.latitude,
  'longitude': instance.longitude,
  'speed': instance.speed,
  'course': instance.course,
  'altitude': instance.altitude,
  'accuracy': instance.accuracy,
  'valid': instance.valid,
  'protocol': instance.protocol,
  'address': instance.address,
  'deviceTime': instance.deviceTime,
  'fixTime': instance.fixTime,
  'serverTime': instance.serverTime,
  'geofenceIds': instance.geofenceIds,
  'raw': instance.raw,
  'index': instance.index,
  'hdop': instance.hdop,
  'vdop': instance.vdop,
  'pdop': instance.pdop,
  'sat': instance.sat,
  'satVisible': instance.satVisible,
  'rssi': instance.rssi,
  'coolantTemp': instance.coolantTemp,
  'engineTemp': instance.engineTemp,
  'attributes': instance.attributes,
};
