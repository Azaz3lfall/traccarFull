// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'device.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Device _$DeviceFromJson(Map<String, dynamic> json) => Device(
  id: (json['id'] as num).toInt(),
  name: json['name'] as String,
  uniqueId: json['uniqueId'] as String,
  phone: json['phone'] as String?,
  model: json['model'] as String?,
  contact: json['contact'] as String?,
  category: json['category'] as String?,
  groupId: (json['groupId'] as num?)?.toInt(),
  calendarId: (json['calendarId'] as num?)?.toInt(),
  expirationTime: json['expirationTime'] as String?,
  attributes: json['attributes'] as Map<String, dynamic>?,
  status: json['status'] as String?,
  lastUpdate: json['lastUpdate'] as String?,
  positionId: (json['positionId'] as num?)?.toInt(),
);

Map<String, dynamic> _$DeviceToJson(Device instance) => <String, dynamic>{
  'id': instance.id,
  'name': instance.name,
  'uniqueId': instance.uniqueId,
  'phone': instance.phone,
  'model': instance.model,
  'contact': instance.contact,
  'category': instance.category,
  'groupId': instance.groupId,
  'calendarId': instance.calendarId,
  'expirationTime': instance.expirationTime,
  'attributes': instance.attributes,
  'status': instance.status,
  'lastUpdate': instance.lastUpdate,
  'positionId': instance.positionId,
};
