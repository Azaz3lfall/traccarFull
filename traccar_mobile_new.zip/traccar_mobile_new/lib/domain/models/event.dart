import 'package:json_annotation/json_annotation.dart';

part 'event.g.dart';

@JsonSerializable()
class Event {
  final int id;
  final String type;
  final int deviceId;
  final int? positionId;
  final String eventTime;
  final int? geofenceId;
  final int? maintenanceId;
  final Map<String, dynamic>? attributes;

  const Event({
    required this.id,
    required this.type,
    required this.deviceId,
    this.positionId,
    required this.eventTime,
    this.geofenceId,
    this.maintenanceId,
    this.attributes,
  });

  factory Event.fromJson(Map<String, dynamic> json) => _$EventFromJson(json);
  Map<String, dynamic> toJson() => _$EventToJson(this);

  Event copyWith({
    int? id,
    String? type,
    int? deviceId,
    int? positionId,
    String? eventTime,
    int? geofenceId,
    int? maintenanceId,
    Map<String, dynamic>? attributes,
  }) {
    return Event(
      id: id ?? this.id,
      type: type ?? this.type,
      deviceId: deviceId ?? this.deviceId,
      positionId: positionId ?? this.positionId,
      eventTime: eventTime ?? this.eventTime,
      geofenceId: geofenceId ?? this.geofenceId,
      maintenanceId: maintenanceId ?? this.maintenanceId,
      attributes: attributes ?? this.attributes,
    );
  }

  @override
  String toString() {
    return 'Event(id: $id, type: $type, deviceId: $deviceId, eventTime: $eventTime)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is Event && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;
}
