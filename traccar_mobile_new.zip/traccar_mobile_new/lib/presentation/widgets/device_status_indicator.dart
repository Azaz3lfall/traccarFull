import 'package:flutter/cupertino.dart';

class DeviceStatusIndicator extends StatelessWidget {
  final String status;
  final double size;

  const DeviceStatusIndicator({
    super.key,
    required this.status,
    this.size = 12.0,
  });

  @override
  Widget build(BuildContext context) {
    Color color;
    IconData icon;

    switch (status.toLowerCase()) {
      case 'online':
        color = CupertinoColors.systemGreen;
        icon = CupertinoIcons.circle_fill;
        break;
      case 'moving':
        color = CupertinoColors.systemBlue;
        icon = CupertinoIcons.location_fill;
        break;
      case 'offline':
        color = CupertinoColors.systemRed;
        icon = CupertinoIcons.circle;
        break;
      case 'alert':
        color = CupertinoColors.systemOrange;
        icon = CupertinoIcons.exclamationmark_triangle_fill;
        break;
      default:
        color = CupertinoColors.systemGrey;
        icon = CupertinoIcons.circle;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: color.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: size,
            color: color,
          ),
          const SizedBox(width: 4),
          Text(
            status.toUpperCase(),
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w600,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}
