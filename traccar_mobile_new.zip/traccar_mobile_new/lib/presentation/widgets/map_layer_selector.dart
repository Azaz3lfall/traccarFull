import 'package:flutter/cupertino.dart';

class MapLayer {
  final String name;
  final String urlTemplate;
  final String attribution;
  final String icon;

  const MapLayer({
    required this.name,
    required this.urlTemplate,
    required this.attribution,
    required this.icon,
  });
}

class MapLayerSelector extends StatefulWidget {
  final MapLayer selectedLayer;
  final Function(MapLayer) onLayerChanged;

  const MapLayerSelector({
    super.key,
    required this.selectedLayer,
    required this.onLayerChanged,
  });

  @override
  State<MapLayerSelector> createState() => _MapLayerSelectorState();
}

class _MapLayerSelectorState extends State<MapLayerSelector> {
  static const List<MapLayer> _mapLayers = [
    MapLayer(
      name: 'OpenStreetMap',
      urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
      attribution: '© OpenStreetMap contributors',
      icon: '🗺️',
    ),
    MapLayer(
      name: 'Google Road',
      urlTemplate: 'https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}',
      attribution: '© Google',
      icon: '🛣️',
    ),
    MapLayer(
      name: 'Google Hybrid',
      urlTemplate: 'https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}',
      attribution: '© Google',
      icon: '🛰️',
    ),
    MapLayer(
      name: 'Google Satellite',
      urlTemplate: 'https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}',
      attribution: '© Google',
      icon: '🛰️',
    ),
    MapLayer(
      name: 'CartoDB Positron',
      urlTemplate: 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png',
      attribution: '© CARTO',
      icon: '🌍',
    ),
    MapLayer(
      name: 'CartoDB Dark',
      urlTemplate: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
      attribution: '© CARTO',
      icon: '🌙',
    ),
    MapLayer(
      name: 'Stamen Terrain',
      urlTemplate: 'https://stamen-tiles.a.ssl.fastly.net/terrain/{z}/{x}/{y}.png',
      attribution: '© Stamen Design',
      icon: '🏔️',
    ),
    MapLayer(
      name: 'Stamen Watercolor',
      urlTemplate: 'https://stamen-tiles.a.ssl.fastly.net/watercolor/{z}/{x}/{y}.jpg',
      attribution: '© Stamen Design',
      icon: '🎨',
    ),
    MapLayer(
      name: 'OpenTopoMap',
      urlTemplate: 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
      attribution: '© OpenTopoMap',
      icon: '🗻',
    ),
    MapLayer(
      name: 'Esri World Imagery',
      urlTemplate: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
      attribution: '© Esri',
      icon: '🛰️',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return CupertinoActionSheet(
      title: const Text('Select Map Layer'),
      message: const Text('Choose your preferred map style'),
      actions: _mapLayers.map((layer) {
        return CupertinoActionSheetAction(
          onPressed: () {
            widget.onLayerChanged(layer);
            Navigator.of(context).pop();
          },
                  child: Row(
          children: [
            Text(
              layer.icon,
              style: const TextStyle(fontSize: 20),
            ),
            const SizedBox(width: 12),
            Text(
              layer.name,
              style: TextStyle(
                fontWeight: layer.name == widget.selectedLayer.name
                    ? FontWeight.bold
                    : FontWeight.normal,
                color: layer.name == widget.selectedLayer.name
                    ? CupertinoColors.systemBlue
                    : CupertinoColors.label,
              ),
            ),
            const Spacer(),
            if (layer.name == widget.selectedLayer.name)
              const Icon(
                CupertinoIcons.checkmark,
                color: CupertinoColors.systemBlue,
              ),
          ],
        ),
        );
      }).toList(),
      cancelButton: CupertinoActionSheetAction(
        onPressed: () => Navigator.of(context).pop(),
        child: const Text('Cancel'),
      ),
    );
  }
}
