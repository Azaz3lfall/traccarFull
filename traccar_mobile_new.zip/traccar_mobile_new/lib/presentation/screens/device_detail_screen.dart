import 'package:flutter/cupertino.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:provider/provider.dart';
import '../../domain/models/device.dart';
import '../../domain/models/position.dart';
import '../../core/utils/device_icons.dart';
import '../providers/position_provider.dart';
import '../widgets/device_status_indicator.dart';
import '../widgets/map_layer_selector.dart';

class DeviceDetailScreen extends StatefulWidget {
  final Device device;

  const DeviceDetailScreen({
    super.key,
    required this.device,
  });

  @override
  State<DeviceDetailScreen> createState() => _DeviceDetailScreenState();
}

class _DeviceDetailScreenState extends State<DeviceDetailScreen> {
  late MapController _mapController;
  Position? _currentPosition;
  List<Position> _historyPositions = [];
  MapLayer _selectedMapLayer = const MapLayer(
    name: 'OpenStreetMap',
    urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
    attribution: '© OpenStreetMap contributors',
    icon: '🗺️',
  );

  @override
  void initState() {
    super.initState();
    _mapController = MapController();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadDeviceData();
      _setupPositionListener();
    });
  }

  void _setupPositionListener() {
    final positionProvider = context.read<PositionProvider>();
    positionProvider.addListener(_onPositionUpdate);
  }

  void _onPositionUpdate() {
    if (mounted) {
      final positionProvider = context.read<PositionProvider>();
      final newPosition = positionProvider.getPositionForDevice(widget.device.id);
      final newHistory = positionProvider.getHistoryForDevice(widget.device.id);
      
      if (newPosition != _currentPosition || newHistory != _historyPositions) {
        setState(() {
          _currentPosition = newPosition;
          _historyPositions = newHistory;
        });
        
        if (newPosition != null) {
          _updateMapView();
        }
      }
    }
  }

  @override
  void dispose() {
    final positionProvider = context.read<PositionProvider>();
    positionProvider.removeListener(_onPositionUpdate);
    super.dispose();
  }

  Future<void> _loadDeviceData() async {
    final positionProvider = context.read<PositionProvider>();
    
    // Get current position
    _currentPosition = positionProvider.getPositionForDevice(widget.device.id);
    
    // Load position history
    await positionProvider.loadPositionsForDevice(widget.device.id);
    _historyPositions = positionProvider.getHistoryForDevice(widget.device.id);
    
    if (mounted) {
      setState(() {});
      _updateMapView();
    }
  }

  void _updateMapView() {
    if (_currentPosition != null) {
      _mapController.move(
        LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
        15.0,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return CupertinoPageScaffold(
      child: Stack(
        children: [
          // Full screen map
          _buildMap(),
          
          // Top controls
          Positioned(
            top: MediaQuery.of(context).padding.top + 10,
            left: 10,
            right: 10,
            child: Row(
              children: [
                // Back button
                CupertinoButton(
                  padding: const EdgeInsets.all(8),
                  onPressed: () => Navigator.of(context).pop(),
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: CupertinoColors.systemBackground.withValues(alpha: 0.9),
                      borderRadius: BorderRadius.circular(8),
                      boxShadow: [
                        BoxShadow(
                          color: CupertinoColors.black.withValues(alpha: 0.1),
                          blurRadius: 4,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: const Icon(
                      CupertinoIcons.back,
                      color: CupertinoColors.label,
                    ),
                  ),
                ),
                
                const Spacer(),
                
                // Device name and status
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: CupertinoColors.systemBackground.withValues(alpha: 0.9),
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: [
                      BoxShadow(
                        color: CupertinoColors.black.withValues(alpha: 0.1),
                        blurRadius: 4,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        widget.device.name,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(width: 8),
                      DeviceStatusIndicator(
                        status: widget.device.status ?? 'offline',
                        size: 12,
                      ),
                    ],
                  ),
                ),
                
                const Spacer(),
                
                // Map layer selector
                CupertinoButton(
                  padding: const EdgeInsets.all(8),
                  onPressed: _showMapLayerSelector,
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: CupertinoColors.systemBackground.withValues(alpha: 0.9),
                      borderRadius: BorderRadius.circular(8),
                      boxShadow: [
                        BoxShadow(
                          color: CupertinoColors.black.withValues(alpha: 0.1),
                          blurRadius: 4,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: const Icon(
                      CupertinoIcons.layers,
                      color: CupertinoColors.label,
                    ),
                  ),
                ),
              ],
            ),
          ),
          
          // Zoom controls
          Positioned(
            right: 10,
            bottom: 100,
            child: Column(
              children: [
                // Zoom in
                CupertinoButton(
                  padding: const EdgeInsets.all(8),
                  onPressed: () {
                    _mapController.move(
                      _mapController.camera.center,
                      _mapController.camera.zoom + 1,
                    );
                  },
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: CupertinoColors.systemBackground.withValues(alpha: 0.9),
                      borderRadius: BorderRadius.circular(8),
                      boxShadow: [
                        BoxShadow(
                          color: CupertinoColors.black.withValues(alpha: 0.1),
                          blurRadius: 4,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: const Icon(
                      CupertinoIcons.add,
                      color: CupertinoColors.label,
                    ),
                  ),
                ),
                
                const SizedBox(height: 4),
                
                // Zoom out
                CupertinoButton(
                  padding: const EdgeInsets.all(8),
                  onPressed: () {
                    _mapController.move(
                      _mapController.camera.center,
                      _mapController.camera.zoom - 1,
                    );
                  },
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: CupertinoColors.systemBackground.withValues(alpha: 0.9),
                      borderRadius: BorderRadius.circular(8),
                      boxShadow: [
                        BoxShadow(
                          color: CupertinoColors.black.withValues(alpha: 0.1),
                          blurRadius: 4,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: const Icon(
                      CupertinoIcons.minus,
                      color: CupertinoColors.label,
                    ),
                  ),
                ),
              ],
            ),
          ),
          
          // Position details overlay
          if (_currentPosition != null)
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: CupertinoColors.systemBackground.withValues(alpha: 0.95),
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(16),
                    topRight: Radius.circular(16),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: CupertinoColors.black.withValues(alpha: 0.1),
                      blurRadius: 8,
                      offset: const Offset(0, -2),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Address
                    Row(
                      children: [
                        const Icon(
                          CupertinoIcons.location,
                          size: 16,
                          color: CupertinoColors.systemBlue,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            _currentPosition!.address ?? 'Unknown location',
                            style: const TextStyle(
                              fontSize: 14,
                              color: CupertinoColors.systemBlue,
                            ),
                          ),
                        ),
                      ],
                    ),
                    
                    const SizedBox(height: 12),
                    
                    // Details grid
                    Row(
                      children: [
                        Expanded(
                          child: _DetailItem(
                            icon: CupertinoIcons.speedometer,
                            label: 'Speed',
                            value: _currentPosition!.speed != null
                                ? '${_currentPosition!.speed!.toStringAsFixed(1)} km/h'
                                : 'N/A',
                          ),
                        ),
                        Expanded(
                          child: _DetailItem(
                            icon: CupertinoIcons.compass,
                            label: 'Course',
                            value: _currentPosition!.course != null
                                ? '${_currentPosition!.course!.toStringAsFixed(0)}°'
                                : 'N/A',
                          ),
                        ),
                      ],
                    ),
                    
                    const SizedBox(height: 8),
                    
                    Row(
                      children: [
                        Expanded(
                          child: _DetailItem(
                            icon: CupertinoIcons.arrow_up_arrow_down,
                            label: 'Altitude',
                            value: _currentPosition!.altitude != null
                                ? '${_currentPosition!.altitude!.toStringAsFixed(0)} m'
                                : 'N/A',
                          ),
                        ),
                        Expanded(
                          child: _DetailItem(
                            icon: CupertinoIcons.time,
                            label: 'Last Update',
                            value: _formatTime(_currentPosition!.serverTime),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildMap() {
    if (_currentPosition == null) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              CupertinoIcons.location_slash,
              size: 64,
              color: CupertinoColors.systemGrey,
            ),
            SizedBox(height: 16),
            Text(
              'No position data available',
              style: TextStyle(
                fontSize: 16,
                color: CupertinoColors.secondaryLabel,
              ),
            ),
          ],
        ),
      );
    }

    return FlutterMap(
      mapController: _mapController,
      options: MapOptions(
        initialCenter: LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
        initialZoom: 15.0,
        minZoom: 3.0,
        maxZoom: 18.0,
      ),
      children: [
        TileLayer(
          urlTemplate: _selectedMapLayer.urlTemplate,
          userAgentPackageName: 'com.traccar.mobile',
        ),
        if (_historyPositions.isNotEmpty)
          PolylineLayer(
            polylines: [
              Polyline(
                points: _historyPositions
                    .map((pos) => LatLng(pos.latitude, pos.longitude))
                    .toList(),
                strokeWidth: 3.0,
                color: CupertinoColors.systemBlue,
              ),
            ],
          ),
        MarkerLayer(
          markers: [
            Marker(
              point: LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
              width: 50,
              height: 50,
              child: Container(
                decoration: BoxDecoration(
                  color: CupertinoColors.systemBlue,
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: CupertinoColors.white,
                    width: 3,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: CupertinoColors.black.withValues(alpha: 0.3),
                      blurRadius: 4,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: DeviceIcons.getIconWidget(
                  widget.device.category,
                  size: 24,
                  color: CupertinoColors.white,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  void _showMapLayerSelector() {
    showCupertinoModalPopup(
      context: context,
      builder: (context) => MapLayerSelector(
        selectedLayer: _selectedMapLayer,
        onLayerChanged: (layer) {
          setState(() {
            _selectedMapLayer = layer;
          });
        },
      ),
    );
  }

  String _formatTime(String? timeString) {
    if (timeString == null) return 'Unknown';
    
    try {
      final time = DateTime.parse(timeString);
      final now = DateTime.now();
      final difference = now.difference(time);
      
      if (difference.inMinutes < 1) {
        return 'Just now';
      } else if (difference.inMinutes < 60) {
        return '${difference.inMinutes}m ago';
      } else if (difference.inHours < 24) {
        return '${difference.inHours}h ago';
      } else {
        return '${difference.inDays}d ago';
      }
    } catch (e) {
      return 'Unknown';
    }
  }
}

class _DetailItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _DetailItem({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(
          icon,
          size: 20,
          color: CupertinoColors.systemBlue,
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(
            fontSize: 12,
            color: CupertinoColors.secondaryLabel,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          value,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}
