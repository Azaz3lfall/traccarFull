import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';
import '../../core/utils/device_icons.dart';
import '../providers/device_provider.dart';
import '../providers/position_provider.dart';
import '../widgets/device_card.dart';
import 'device_detail_screen.dart';

class DeviceListScreen extends StatefulWidget {
  const DeviceListScreen({super.key});

  @override
  State<DeviceListScreen> createState() => _DeviceListScreenState();
}

class _DeviceListScreenState extends State<DeviceListScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<DeviceProvider>().initialize();
    });
  }

  void _onDeviceTap(device) {
    Navigator.of(context).push(
      CupertinoPageRoute(
        builder: (context) => DeviceDetailScreen(device: device),
      ),
    );
  }

  void _onRefresh() async {
    if (mounted) {
      final deviceProvider = context.read<DeviceProvider>();
      final positionProvider = context.read<PositionProvider>();
      await deviceProvider.refreshDevices();
      await positionProvider.refreshPositions();
    }
  }

  @override
  Widget build(BuildContext context) {
    return CupertinoPageScaffold(
      child: Stack(
        children: [
          // Main content
          Consumer2<DeviceProvider, PositionProvider>(
        builder: (context, deviceProvider, positionProvider, child) {
          if (deviceProvider.isLoading && deviceProvider.devices.isEmpty) {
            return Padding(
              padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 60),
              child: const Center(
                child: CupertinoActivityIndicator(),
              ),
            );
          }

          if (deviceProvider.error != null) {
            return Padding(
              padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 60),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(
                      CupertinoIcons.exclamationmark_triangle,
                      size: 64,
                      color: CupertinoColors.systemRed,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Error loading devices',
                      style: CupertinoTheme.of(context).textTheme.navTitleTextStyle,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      deviceProvider.error!,
                      style: CupertinoTheme.of(context).textTheme.textStyle,
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    CupertinoButton.filled(
                      onPressed: _onRefresh,
                      child: const Text('Retry'),
                    ),
                  ],
                ),
              ),
            );
          }

          final devices = deviceProvider.filteredDevices;

          if (devices.isEmpty) {
            return Padding(
              padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 60),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(
                      CupertinoIcons.location_slash,
                      size: 64,
                      color: CupertinoColors.systemGrey,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      deviceProvider.searchQuery.isEmpty
                          ? 'No devices found'
                          : 'No devices match your search',
                      style: CupertinoTheme.of(context).textTheme.navTitleTextStyle,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      deviceProvider.searchQuery.isEmpty
                          ? 'Add devices in the Traccar web interface'
                          : 'Try a different search term',
                      style: CupertinoTheme.of(context).textTheme.textStyle,
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            );
          }

          return CustomScrollView(
            slivers: [
              // Top padding for overlay controls
              SliverToBoxAdapter(
                child: SizedBox(height: MediaQuery.of(context).padding.top + 60),
              ),
              
              // Search bar
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: CupertinoSearchTextField(
                    placeholder: 'Search devices...',
                    onChanged: deviceProvider.setSearchQuery,
                  ),
                ),
              ),
              
              // Status summary
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: _StatusCard(
                          title: 'Online',
                          count: deviceProvider.onlineDevices.length,
                          color: CupertinoColors.systemGreen,
                          icon: CupertinoIcons.checkmark_circle_fill,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _StatusCard(
                          title: 'Moving',
                          count: deviceProvider.movingDevices.length,
                          color: CupertinoColors.systemBlue,
                          icon: CupertinoIcons.location_fill,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _StatusCard(
                          title: 'Offline',
                          count: deviceProvider.offlineDevices.length,
                          color: CupertinoColors.systemRed,
                          icon: CupertinoIcons.xmark_circle_fill,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              
              const SliverToBoxAdapter(
                child: SizedBox(height: 16),
              ),
              
              // Device list
              SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) {
                    final device = devices[index];
                    final position = positionProvider.getPositionForDevice(device.id);
                    
                    return Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16.0,
                        vertical: 4.0,
                      ),
                      child: DeviceCard(
                        device: device,
                        position: position,
                        onTap: () => _onDeviceTap(device),
                      ),
                    );
                  },
                  childCount: devices.length,
                ),
              ),
            ],
          );
        },
      ),
          
          // Top controls overlay
          Positioned(
            top: MediaQuery.of(context).padding.top + 10,
            left: 10,
            right: 10,
            child: Row(
              children: [
                // Title
                const Text(
                  'Devices',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                
                const Spacer(),
                
                // Refresh button
                CupertinoButton(
                  padding: const EdgeInsets.all(8),
                  onPressed: _onRefresh,
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: CupertinoColors.systemBackground.withValues(alpha: 0.9),
                      borderRadius: BorderRadius.circular(8),
                      boxShadow: [
                        BoxShadow(
                          color: CupertinoColors.black.withValues(alpha: 0.1),
                          blurRadius: 4,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: const Icon(
                      CupertinoIcons.refresh,
                      color: CupertinoColors.label,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _StatusCard extends StatelessWidget {
  final String title;
  final int count;
  final Color color;
  final IconData icon;

  const _StatusCard({
    required this.title,
    required this.count,
    required this.color,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: color.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          Icon(
            icon,
            size: 20,
            color: color,
          ),
          const SizedBox(height: 4),
          Text(
            count.toString(),
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            title,
            style: TextStyle(
              fontSize: 12,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}
