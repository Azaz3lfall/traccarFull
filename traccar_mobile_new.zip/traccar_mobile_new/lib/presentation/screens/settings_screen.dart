import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  @override
  Widget build(BuildContext context) {
    return CupertinoPageScaffold(
      navigationBar: const CupertinoNavigationBar(
        middle: Text('Settings'),
      ),
      child: Consumer<AuthProvider>(
        builder: (context, authProvider, child) {
          return ListView(
            children: [
              // User info section
              Container(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Account',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),
                    if (authProvider.user != null) ...[
                      _SettingsItem(
                        icon: CupertinoIcons.person,
                        title: 'Name',
                        subtitle: authProvider.user!.name,
                      ),
                      _SettingsItem(
                        icon: CupertinoIcons.mail,
                        title: 'Email',
                        subtitle: authProvider.user!.email,
                      ),
                      if (authProvider.user!.phone != null)
                        _SettingsItem(
                          icon: CupertinoIcons.phone,
                          title: 'Phone',
                          subtitle: authProvider.user!.phone!,
                        ),
                    ],
                  ],
                ),
              ),
              
              const SizedBox(height: 16),
              
              // App settings section
              Container(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'App Settings',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),
                    _SettingsItem(
                      icon: CupertinoIcons.globe,
                      title: 'Server URL',
                      subtitle: 'https://demo.traccar.org',
                      onTap: () {
                        // TODO: Implement server URL change
                      },
                    ),
                    _SettingsItem(
                      icon: CupertinoIcons.bell,
                      title: 'Notifications',
                      subtitle: 'Configure push notifications',
                      onTap: () {
                        // TODO: Implement notifications settings
                      },
                    ),
                    _SettingsItem(
                      icon: CupertinoIcons.map,
                      title: 'Map Settings',
                      subtitle: 'Configure map layers and preferences',
                      onTap: () {
                        // TODO: Implement map settings
                      },
                    ),
                  ],
                ),
              ),
              
              const SizedBox(height: 16),
              
              // About section
              Container(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'About',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),
                    _SettingsItem(
                      icon: CupertinoIcons.info,
                      title: 'Version',
                      subtitle: '1.0.0',
                    ),
                    _SettingsItem(
                      icon: CupertinoIcons.doc_text,
                      title: 'Privacy Policy',
                      onTap: () {
                        // TODO: Implement privacy policy
                      },
                    ),
                    _SettingsItem(
                      icon: CupertinoIcons.question_circle,
                      title: 'Help & Support',
                      onTap: () {
                        // TODO: Implement help & support
                      },
                    ),
                  ],
                ),
              ),
              
              const SizedBox(height: 16),
              
              // Logout section
              Container(
                padding: const EdgeInsets.all(16),
                child: CupertinoButton(
                  color: CupertinoColors.systemRed,
                  onPressed: () {
                    _showLogoutDialog(context);
                  },
                  child: const Text('Sign Out'),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    showCupertinoDialog(
      context: context,
      builder: (context) => CupertinoAlertDialog(
        title: const Text('Sign Out'),
        content: const Text('Are you sure you want to sign out?'),
        actions: [
          CupertinoDialogAction(
            child: const Text('Cancel'),
            onPressed: () => Navigator.of(context).pop(),
          ),
          CupertinoDialogAction(
            isDestructiveAction: true,
            child: const Text('Sign Out'),
            onPressed: () {
              Navigator.of(context).pop();
              context.read<AuthProvider>().logout();
              Navigator.of(context).pushReplacementNamed('/login');
            },
          ),
        ],
      ),
    );
  }
}

class _SettingsItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final VoidCallback? onTap;

  const _SettingsItem({
    required this.icon,
    required this.title,
    this.subtitle,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return CupertinoButton(
      padding: EdgeInsets.zero,
      onPressed: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        child: Row(
          children: [
            Icon(
              icon,
              size: 24,
              color: CupertinoColors.systemBlue,
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  if (subtitle != null) ...[
                    const SizedBox(height: 2),
                    Text(
                      subtitle!,
                      style: const TextStyle(
                        fontSize: 14,
                        color: CupertinoColors.secondaryLabel,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            if (onTap != null)
              const Icon(
                CupertinoIcons.chevron_right,
                size: 16,
                color: CupertinoColors.secondaryLabel,
              ),
          ],
        ),
      ),
    );
  }
}
