import 'package:flutter/foundation.dart';
import '../../data/repositories/position_repository.dart';
import '../../data/services/websocket_service.dart';
import '../../domain/models/position.dart';

class PositionProvider with ChangeNotifier {
  final PositionRepository _positionRepository = PositionRepository();
  final WebSocketService _websocketService = WebSocketService();

  Map<int, Position> _positions = {};
  final Map<int, List<Position>> _deviceHistory = {};
  bool _isLoading = false;
  String? _error;

  Map<int, Position> get positions => _positions;
  Map<int, List<Position>> get deviceHistory => _deviceHistory;
  bool get isLoading => _isLoading;
  String? get error => _error;

  List<Position> get allPositions => _positions.values.toList();

  Future<void> initialize(String serverUrl) async {
    await _websocketService.initialize(serverUrl);
    _setupWebSocketListeners();
    await loadPositions();
  }

  void _setupWebSocketListeners() {
    _websocketService.positionsStream.listen((positions) {
      _updatePositions(positions);
    });
  }

  Future<void> loadPositions() async {
    _setLoading(true);
    _clearError();

    try {
      final positions = await _positionRepository.getPositions();
      _positions = _positionRepository.getLatestPositions(positions);
      notifyListeners();
    } catch (e) {
      _setError(e.toString());
    } finally {
      _setLoading(false);
    }
  }

  Future<void> loadPositionsForDevice(int deviceId) async {
    _setLoading(true);
    _clearError();

    try {
      final positions = await _positionRepository.getPositionsForDevice(deviceId);
      _deviceHistory[deviceId] = positions;
      notifyListeners();
    } catch (e) {
      _setError(e.toString());
    } finally {
      _setLoading(false);
    }
  }

  Future<void> refreshPositions() async {
    await loadPositions();
  }

  Position? getPositionForDevice(int deviceId) {
    return _positions[deviceId];
  }

  List<Position> getHistoryForDevice(int deviceId) {
    return _deviceHistory[deviceId] ?? [];
  }

  List<Position> getPositionsInTimeRange(DateTime from, DateTime to) {
    return _positionRepository.filterPositionsByTimeRange(allPositions, from, to);
  }

  List<Position> getPositionsBySpeed(double minSpeed, double maxSpeed) {
    return _positionRepository.filterPositionsBySpeed(allPositions, minSpeed, maxSpeed);
  }

  void _updatePositions(Map<int, Position> positions) {
    _positions.addAll(positions);
    
    // Update device history for live routes
    for (final position in positions.values) {
      final deviceId = position.deviceId;
      final history = _deviceHistory[deviceId] ?? [];
      
      // Add new position to history if it's different from the last one
      if (history.isEmpty || 
          history.last.latitude != position.latitude || 
          history.last.longitude != position.longitude) {
        history.add(position);
        
        // Keep only last 10 positions for live route
        if (history.length > 10) {
          history.removeAt(0);
        }
        
        _deviceHistory[deviceId] = history;
      }
    }
    
    notifyListeners();
  }

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void _setError(String error) {
    _error = error;
    notifyListeners();
  }

  void _clearError() {
    _error = null;
    notifyListeners();
  }

}
