import 'package:flutter/foundation.dart';
import '../../core/utils/api_client.dart';
import '../../core/configs/app_config.dart';
import '../../domain/models/user.dart';
import 'position_provider.dart';

class AuthProvider with ChangeNotifier {
  final ApiClient _apiClient = ApiClient();
  
  User? _user;
  bool _isLoading = false;
  String? _error;

  User? get user => _user;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isAuthenticated => _user != null;

  Future<void> initialize() async {
    await AppConfig.init();
    if (AppConfig.isLoggedIn) {
      // Try to get current user info
      try {
        _user = await _apiClient.getCurrentUser();
        notifyListeners();
      } catch (e) {
        // If failed, clear login state
        await logout();
      }
    }
  }

  Future<bool> login(String email, String password, String serverUrl, PositionProvider positionProvider) async {
    _setLoading(true);
    _clearError();

    try {
      await _apiClient.initialize(serverUrl);
      _user = await _apiClient.login(email, password);
      
      // Save credentials and login state
      await AppConfig.setServerUrl(serverUrl);
      await AppConfig.setUserEmail(email);
      await AppConfig.setUserPassword(password);
      await AppConfig.setLoggedIn(true);
      
      // Initialize WebSocket connection for real-time updates
      await positionProvider.initialize(serverUrl);
      
      notifyListeners();
      return true;
    } catch (e) {
      _setError(e.toString());
      return false;
    } finally {
      _setLoading(false);
    }
  }

  Future<void> logout() async {
    _setLoading(true);
    
    try {
      await _apiClient.logout();
    } catch (e) {
      // Ignore logout errors
    } finally {
      _user = null;
      await AppConfig.logout();
      _setLoading(false);
      notifyListeners();
    }
  }

  Future<bool> checkConnection() async {
    if (!isAuthenticated) return false;
    
    try {
      await _apiClient.getCurrentUser();
      return true;
    } catch (e) {
      return false;
    }
  }

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void _setError(String error) {
    _error = error;
    notifyListeners();
  }

  void _clearError() {
    _error = null;
    notifyListeners();
  }
}
