import 'package:flutter/foundation.dart';
import '../../data/repositories/device_repository.dart';
import '../../data/services/websocket_service.dart';
import '../../domain/models/device.dart';

class DeviceProvider with ChangeNotifier {
  final DeviceRepository _deviceRepository = DeviceRepository();
  final WebSocketService _websocketService = WebSocketService();

  List<Device> _devices = [];
  Map<int, Device> _devicesMap = {};
  bool _isLoading = false;
  String? _error;
  String _searchQuery = '';

  List<Device> get devices => _devices;
  Map<int, Device> get devicesMap => _devicesMap;
  bool get isLoading => _isLoading;
  String? get error => _error;
  String get searchQuery => _searchQuery;

  List<Device> get filteredDevices {
    if (_searchQuery.isEmpty) return _devices;
    
    return _devices.where((device) =>
        device.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
        device.uniqueId.toLowerCase().contains(_searchQuery.toLowerCase()) ||
        (device.phone?.toLowerCase().contains(_searchQuery.toLowerCase()) ?? false) ||
        (device.model?.toLowerCase().contains(_searchQuery.toLowerCase()) ?? false)
    ).toList();
  }

  List<Device> get onlineDevices => _devices.where((device) => device.status == 'online').toList();
  List<Device> get offlineDevices => _devices.where((device) => device.status == 'offline').toList();
  List<Device> get movingDevices => _devices.where((device) => device.status == 'moving').toList();

  Future<void> initialize() async {
    _setupWebSocketListeners();
    await loadDevices();
  }

  void _setupWebSocketListeners() {
    _websocketService.devicesStream.listen((devices) {
      _updateDevices(devices);
    });
  }

  Future<void> loadDevices() async {
    _setLoading(true);
    _clearError();

    try {
      _devices = await _deviceRepository.getDevices();
      _updateDevicesMap();
      notifyListeners();
    } catch (e) {
      _setError(e.toString());
    } finally {
      _setLoading(false);
    }
  }

  Future<void> refreshDevices() async {
    await loadDevices();
  }

  Future<Device?> getDevice(int id) async {
    try {
      return await _deviceRepository.getDevice(id);
    } catch (e) {
      _setError(e.toString());
      return null;
    }
  }

  Future<Device?> createDevice(Device device) async {
    try {
      final newDevice = await _deviceRepository.createDevice(device);
      _devices.add(newDevice);
      _updateDevicesMap();
      notifyListeners();
      return newDevice;
    } catch (e) {
      _setError(e.toString());
      return null;
    }
  }

  Future<Device?> updateDevice(int id, Device device) async {
    try {
      final updatedDevice = await _deviceRepository.updateDevice(id, device);
      final index = _devices.indexWhere((d) => d.id == id);
      if (index != -1) {
        _devices[index] = updatedDevice;
        _updateDevicesMap();
        notifyListeners();
      }
      return updatedDevice;
    } catch (e) {
      _setError(e.toString());
      return null;
    }
  }

  Future<bool> deleteDevice(int id) async {
    try {
      await _deviceRepository.deleteDevice(id);
      _devices.removeWhere((d) => d.id == id);
      _devicesMap.remove(id);
      notifyListeners();
      return true;
    } catch (e) {
      _setError(e.toString());
      return false;
    }
  }

  void setSearchQuery(String query) {
    _searchQuery = query;
    notifyListeners();
  }

  void clearSearch() {
    _searchQuery = '';
    notifyListeners();
  }

  void _updateDevices(List<Device> devices) {
    _devices = devices;
    _updateDevicesMap();
    notifyListeners();
  }

  void _updateDevicesMap() {
    _devicesMap = {for (var device in _devices) device.id: device};
  }

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void _setError(String error) {
    _error = error;
    notifyListeners();
  }

  void _clearError() {
    _error = null;
    notifyListeners();
  }

}
