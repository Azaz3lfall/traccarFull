import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';
import 'core/configs/app_config.dart';
import 'presentation/providers/auth_provider.dart';
import 'presentation/providers/device_provider.dart';
import 'presentation/providers/position_provider.dart';
import 'presentation/screens/login_screen.dart';
import 'presentation/screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppConfig.init();
  runApp(const TraccarMobileApp());
}

class TraccarMobileApp extends StatelessWidget {
  const TraccarMobileApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => DeviceProvider()),
        ChangeNotifierProvider(create: (_) => PositionProvider()),
      ],
      child: Consumer<AuthProvider>(
        builder: (context, authProvider, child) {
          return CupertinoApp(
            title: 'Traccar Mobile',
            theme: const CupertinoThemeData(
              primaryColor: CupertinoColors.systemBlue,
              scaffoldBackgroundColor: CupertinoColors.systemBackground,
              brightness: Brightness.light,
            ),
            home: authProvider.isAuthenticated
                ? const HomeScreen()
                : const LoginScreen(),
            routes: {
              '/login': (context) => const LoginScreen(),
              '/home': (context) => const HomeScreen(),
            },
            debugShowCheckedModeBanner: false,
          );
        },
      ),
    );
  }
}