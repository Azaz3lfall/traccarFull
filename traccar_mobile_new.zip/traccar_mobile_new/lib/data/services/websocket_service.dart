import 'dart:async';
import 'dart:convert';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import '../../domain/models/device.dart';
import '../../domain/models/position.dart';
import '../../domain/models/event.dart';

class WebSocketService {
  static final WebSocketService _instance = WebSocketService._internal();
  factory WebSocketService() => _instance;
  WebSocketService._internal();

  WebSocketChannel? _channel;
  Timer? _reconnectTimer;
  bool _isConnected = false;
  bool _shouldReconnect = true;
  String _baseUrl = 'wss://demo.traccar.org';
  
  // Stream controllers for real-time updates
  final StreamController<List<Device>> _devicesController = StreamController<List<Device>>.broadcast();
  final StreamController<Map<int, Position>> _positionsController = StreamController<Map<int, Position>>.broadcast();
  final StreamController<List<Event>> _eventsController = StreamController<List<Event>>.broadcast();
  final StreamController<bool> _connectionController = StreamController<bool>.broadcast();

  // Getters for streams
  Stream<List<Device>> get devicesStream => _devicesController.stream;
  Stream<Map<int, Position>> get positionsStream => _positionsController.stream;
  Stream<List<Event>> get eventsStream => _eventsController.stream;
  Stream<bool> get connectionStream => _connectionController.stream;

  bool get isConnected => _isConnected;

  Future<void> initialize(String baseUrl) async {
    _baseUrl = baseUrl.replaceFirst('http', 'ws');
    await connect();
  }

  Future<void> connect() async {
    if (_isConnected) return;

    try {
      final wsUrl = '$_baseUrl/api/socket';
      _channel = WebSocketChannel.connect(Uri.parse(wsUrl));

      _channel!.stream.listen(
        _onMessage,
        onError: _onError,
        onDone: _onDone,
      );

      _isConnected = true;
      _connectionController.add(true);
      print('WebSocket connected to $wsUrl');
    } catch (e) {
      print('WebSocket connection failed: $e');
      _scheduleReconnect();
    }
  }

  void _onMessage(dynamic message) {
    try {
      final data = json.decode(message);
      
      if (data['devices'] != null) {
        final devices = (data['devices'] as List)
            .map((json) => Device.fromJson(json))
            .toList();
        _devicesController.add(devices);
      }

      if (data['positions'] != null) {
        final positions = <int, Position>{};
        for (final json in data['positions']) {
          final position = Position.fromJson(json);
          positions[position.deviceId] = position;
        }
        _positionsController.add(positions);
      }

      if (data['events'] != null) {
        final events = (data['events'] as List)
            .map((json) => Event.fromJson(json))
            .toList();
        _eventsController.add(events);
      }
    } catch (e) {
      print('Error parsing WebSocket message: $e');
    }
  }

  void _onError(error) {
    print('WebSocket error: $error');
    _isConnected = false;
    _connectionController.add(false);
    _scheduleReconnect();
  }

  void _onDone() {
    print('WebSocket connection closed');
    _isConnected = false;
    _connectionController.add(false);
    _scheduleReconnect();
  }

  void _scheduleReconnect() {
    if (!_shouldReconnect) return;

    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(const Duration(seconds: 60), () {
      if (_shouldReconnect && !_isConnected) {
        print('Attempting to reconnect WebSocket...');
        connect();
      }
    });
  }

  Future<void> sendMessage(Map<String, dynamic> message) async {
    if (_channel != null && _isConnected) {
      _channel!.sink.add(json.encode(message));
    }
  }

  Future<void> enableLogs(bool enabled) async {
    await sendMessage({'logs': enabled});
  }

  Future<void> disconnect() async {
    _shouldReconnect = false;
    _reconnectTimer?.cancel();
    _channel?.sink.close(status.goingAway);
    _isConnected = false;
    _connectionController.add(false);
  }

  void dispose() {
    disconnect();
    _devicesController.close();
    _positionsController.close();
    _eventsController.close();
    _connectionController.close();
  }
}
