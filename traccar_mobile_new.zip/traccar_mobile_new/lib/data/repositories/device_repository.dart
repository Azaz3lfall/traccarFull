import '../../core/utils/api_client.dart';
import '../../domain/models/device.dart';

class DeviceRepository {
  final ApiClient _apiClient = ApiClient();

  Future<List<Device>> getDevices() async {
    return await _apiClient.getDevices();
  }

  Future<Device> getDevice(int id) async {
    return await _apiClient.getDevice(id);
  }

  Future<Device> createDevice(Device device) async {
    return await _apiClient.createDevice(device);
  }

  Future<Device> updateDevice(int id, Device device) async {
    return await _apiClient.updateDevice(id, device);
  }

  Future<void> deleteDevice(int id) async {
    await _apiClient.deleteDevice(id);
  }

  Future<List<Device>> searchDevices(String query) async {
    final devices = await getDevices();
    return devices.where((device) =>
        device.name.toLowerCase().contains(query.toLowerCase()) ||
        device.uniqueId.toLowerCase().contains(query.toLowerCase()) ||
        (device.phone?.toLowerCase().contains(query.toLowerCase()) ?? false) ||
        (device.model?.toLowerCase().contains(query.toLowerCase()) ?? false)
    ).toList();
  }

  List<Device> filterDevicesByStatus(List<Device> devices, String status) {
    return devices.where((device) => device.status == status).toList();
  }

  List<Device> filterDevicesByGroup(List<Device> devices, int groupId) {
    return devices.where((device) => device.groupId == groupId).toList();
  }
}
