import '../../core/utils/api_client.dart';
import '../../domain/models/event.dart';

class EventRepository {
  final ApiClient _apiClient = ApiClient();

  Future<List<Event>> getEvents({
    int? deviceId,
    String? from,
    String? to,
    String? type,
  }) async {
    return await _apiClient.getEvents(
      deviceId: deviceId,
      from: from,
      to: to,
      type: type,
    );
  }

  Future<Event> getEvent(int id) async {
    return await _apiClient.getEvent(id);
  }

  Future<List<Event>> getEventsForDevice(int deviceId, {
    String? from,
    String? to,
  }) async {
    return await getEvents(
      deviceId: deviceId,
      from: from,
      to: to,
    );
  }

  List<Event> filterEventsByType(List<Event> events, String type) {
    return events.where((event) => event.type == type).toList();
  }

  List<Event> filterEventsByTimeRange(
    List<Event> events,
    DateTime from,
    DateTime to,
  ) {
    return events.where((event) {
      final eventTime = DateTime.tryParse(event.eventTime);
      if (eventTime == null) return false;
      return eventTime.isAfter(from) && eventTime.isBefore(to);
    }).toList();
  }

  List<Event> filterEventsByGeofence(List<Event> events, int geofenceId) {
    return events.where((event) => event.geofenceId == geofenceId).toList();
  }

  List<Event> sortEventsByTime(List<Event> events, {bool ascending = true}) {
    final sortedEvents = List<Event>.from(events);
    sortedEvents.sort((a, b) {
      final timeA = DateTime.tryParse(a.eventTime) ?? DateTime(1970);
      final timeB = DateTime.tryParse(b.eventTime) ?? DateTime(1970);
      return ascending ? timeA.compareTo(timeB) : timeB.compareTo(timeA);
    });
    return sortedEvents;
  }
}
