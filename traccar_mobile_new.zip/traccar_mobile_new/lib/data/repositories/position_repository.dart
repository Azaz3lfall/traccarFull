import '../../core/utils/api_client.dart';
import '../../domain/models/position.dart';

class PositionRepository {
  final ApiClient _apiClient = ApiClient();

  Future<List<Position>> getPositions({int? deviceId}) async {
    return await _apiClient.getPositions(deviceId: deviceId);
  }

  Future<Position> getPosition(int id) async {
    return await _apiClient.getPosition(id);
  }

  Future<List<Position>> getPositionsForDevice(int deviceId, {
    String? from,
    String? to,
  }) async {
    return await _apiClient.getPositions(deviceId: deviceId);
  }

  Map<int, Position> getLatestPositions(List<Position> positions) {
    final Map<int, Position> latestPositions = {};
    
    for (final position in positions) {
      if (!latestPositions.containsKey(position.deviceId) ||
          (latestPositions[position.deviceId]?.serverTime ?? '').compareTo(position.serverTime ?? '') < 0) {
        latestPositions[position.deviceId] = position;
      }
    }
    
    return latestPositions;
  }

  List<Position> filterPositionsByTimeRange(
    List<Position> positions,
    DateTime from,
    DateTime to,
  ) {
    return positions.where((position) {
      final positionTime = DateTime.tryParse(position.serverTime ?? '');
      if (positionTime == null) return false;
      return positionTime.isAfter(from) && positionTime.isBefore(to);
    }).toList();
  }

  List<Position> filterPositionsBySpeed(
    List<Position> positions,
    double minSpeed,
    double maxSpeed,
  ) {
    return positions.where((position) {
      final speed = position.speed ?? 0.0;
      return speed >= minSpeed && speed <= maxSpeed;
    }).toList();
  }
}
